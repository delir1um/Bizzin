alter table profiles enable row level security;
alter table tenants enable row level security;
alter table tenant_members enable row level security;
alter table goals enable row level security;
alter table journal_entries enable row level security;
alter table documents enable row level security;
alter table payments enable row level security;
alter table milestones enable row level security;
